//
//  logtext.h
//  fdfsf
//
//  Created by EinFachMann on 14-1-10.
//
//

#import <Foundation/Foundation.h>

@interface logtext : NSObject

//写文件
+(void) LOGSTRTOFILE:(NSString*)str;

@end
