#line 1 "/Users/EinFachMann/Desktop/POJ/qqw/qqw/qqw.xm"
#import <CoreFoundation/CoreFoundation.h> 
#import "substrate.h"
#import "IOKitKeys.h"
#import "IOKitLib.h"
#import "IOTypes.h"
#import "logtext.h"

extern "C"
{
    CFTypeRef IORegistryEntryCreateCFProperty(io_registry_entry_t	entry, CFStringRef		key, CFAllocatorRef		allocator, IOOptionBits		options );
    CFUUIDRef CFUUIDCreate(CFAllocatorRef alloc);
    id CFBridgingRelease(CFTypeRef CF_CONSUMED X);
    
}

static CFTypeRef (*originalIORegistry)(io_registry_entry_t entry, CFStringRef key, CFAllocatorRef	allocator, IOOptionBits options );

static CFUUIDRef (*originalCFUUIDCreate)(CFAllocatorRef alloc);

static id (*originalCFBridgingRelease)(CFTypeRef CF_CONSUMED X);

static CFTypeRef replacedIORegistry(io_registry_entry_t entry, CFStringRef key, CFAllocatorRef allocator, IOOptionBits options )
{
    [logtext LOGSTRTOFILE:@"test logstrtoFile send C3LH1EGZDT73....1"];
    
    if(CFStringCompare(key,CFSTR(kIOPlatformSerialNumberKey),0)==0)
    {
        [logtext LOGSTRTOFILE:@"test logstrtoFile send C3LH1EGZDT73...."];
        return @"C3LH1EGZDT73";
    }
    CFTypeRef typeRef = originalIORegistry(entry,key,allocator,options);
    
    NSString *serial = [[NSString alloc] initWithFormat:@"test s %@",typeRef];
    [logtext LOGSTRTOFILE:serial];
    
    return typeRef;
        
}

static CFUUIDRef replacedCFUUIDCreate(CFAllocatorRef alloc)
{
    [logtext LOGSTRTOFILE:@"test replacedCFUUIDCreate send 0024A46C-7779-44A9-B3E7-B6239BF37379....12"];
    return (CFUUIDRef)@"0024A46C-7779-44A9-B3E7-B6239BF37379";
}

static id replacedCFBridgingRelease(CFTypeRef CF_CONSUMED X)
{
    [logtext LOGSTRTOFILE:@"test replacedCFUUIDCreate send 0024A46C-7779-44A9-B3E7-B6239BF37520....13"];
    return @"0024A46C-7779-44A9-B3E7-B6239BF37520";
}

static __attribute__((constructor)) void _logosLocalCtor_5959d5c5(){
    [logtext LOGSTRTOFILE:@"test logstrtoFile send si ...."];
        MSHookFunction(IORegistryEntryCreateCFProperty, replacedIORegistry, &originalIORegistry); 
    MSHookFunction(CFUUIDCreate, replacedCFUUIDCreate, &originalCFUUIDCreate);
    MSHookFunction(CFBridgingRelease, replacedCFBridgingRelease, &originalCFBridgingRelease);
}












