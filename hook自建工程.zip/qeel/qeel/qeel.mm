//
//  qeel.mm
//  qeel
//
//  Created by EinFachMann on 14-1-10.
//  Copyright (c) 2014年 __MyCompanyName__. All rights reserved.
//

// CaptainHook by Ryan Petrich
// see https://github.com/rpetrich/CaptainHook/

#import <Foundation/Foundation.h>
#import "CaptainHook/CaptainHook.h"
#include <notify.h> // not required; for examples only

// Objective-C runtime hooking using CaptainHook:
//   1. declare class using CHDeclareClass()
//   2. load class using CHLoadClass() or CHLoadLateClass() in CHConstructor
//   3. hook method using CHOptimizedMethod()
//   4. register hook using CHHook() in CHConstructor
//   5. (optionally) call old method using CHSuper()


@interface qeel : NSObject

@end

@implementation qeel

-(id)init
{
	if ((self = [super init]))
	{
	}

    return self;
}

@end


@class NSString;

CHDeclareClass(NSString); // declare class

CHOptimizedMethod(0, self, NSUInteger, NSString, length) // hook method (with 2 arguments and a return value)
{
	// write code here ...

	CHSuper(0, NSString, length); // call old (original) method and return its return value
    return 1;
}

//static void WillEnterForeground(CFNotificationCenterRef center, void *observer, CFStringRef name, const void *object, CFDictionaryRef userInfo)
//{
//	// not required; for example only
//}
//
//static void ExternallyPostedNotification(CFNotificationCenterRef center, void *observer, CFStringRef name, const void *object, CFDictionaryRef userInfo)
//{
//	// not required; for example only
//}

CHConstructor // code block that runs immediately upon load
{
	@autoreleasepool
	{
//		// listen for local notification (not required; for example only)
//		CFNotificationCenterRef center = CFNotificationCenterGetLocalCenter();
//		CFNotificationCenterAddObserver(center, NULL, WillEnterForeground, CFSTR("UIApplicationWillEnterForegroundNotification"), NULL, CFNotificationSuspensionBehaviorCoalesce);
//		
//		// listen for system-side notification (not required; for example only)
//		// this would be posted using: notify_post("com.cb.issdkd.qeel.eventname");
//		CFNotificationCenterRef darwin = CFNotificationCenterGetDarwinNotifyCenter();
//		CFNotificationCenterAddObserver(darwin, NULL, ExternallyPostedNotification, CFSTR("com.cb.issdkd.qeel.eventname"), NULL, CFNotificationSuspensionBehaviorCoalesce);
		
		// CHLoadClass(ClassToHook); // load class (that is "available now")
		// CHLoadLateClass(ClassToHook);  // load class (that will be "available later")
		
		CHHook(0, NSString, length); // register hook
	}
}
