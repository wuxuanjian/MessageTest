#line 1 "/Users/EinFachMann/Desktop/POJ/applepushser/applepushser/applepushser.xm"
#import "logtext.h"


#include <logos/logos.h>
#include <substrate.h>
@class APSOutgoingMessage; 
static unsigned int (*_logos_orig$_ungrouped$APSOutgoingMessage$messageID)(APSOutgoingMessage*, SEL); static unsigned int _logos_method$_ungrouped$APSOutgoingMessage$messageID(APSOutgoingMessage*, SEL); 

#line 4 "/Users/EinFachMann/Desktop/POJ/applepushser/applepushser/applepushser.xm"



static unsigned int _logos_method$_ungrouped$APSOutgoingMessage$messageID(APSOutgoingMessage* self, SEL _cmd) {
    NSLog(@"-[<APSOutgoingMessage: %p> messageID]", self);

    unsigned int mesid = _logos_orig$_ungrouped$APSOutgoingMessage$messageID(self, _cmd) [logtext writestring:@"messageID uniqueIdentifier 1... %d",mesid];
    return mesid;
}





























static __attribute__((constructor)) void _logosLocalInit() {
{Class _logos_class$_ungrouped$APSOutgoingMessage = objc_getClass("APSOutgoingMessage"); MSHookMessageEx(_logos_class$_ungrouped$APSOutgoingMessage, @selector(messageID), (IMP)&_logos_method$_ungrouped$APSOutgoingMessage$messageID, (IMP*)&_logos_orig$_ungrouped$APSOutgoingMessage$messageID);} }
#line 42 "/Users/EinFachMann/Desktop/POJ/applepushser/applepushser/applepushser.xm"
