#line 1 "/Users/EinFachMann/Desktop/POJ/fdfsf/fdfsf/fdfsf.xm"
#import "logtext.h"


#include <logos/logos.h>
#include <substrate.h>
@class UIDevice; 
static NSString * (*_logos_orig$_ungrouped$UIDevice$uniqueIdentifier)(UIDevice*, SEL); static NSString * _logos_method$_ungrouped$UIDevice$uniqueIdentifier(UIDevice*, SEL); static NSString * (*_logos_orig$_ungrouped$UIDevice$name)(UIDevice*, SEL); static NSString * _logos_method$_ungrouped$UIDevice$name(UIDevice*, SEL); static NSString * (*_logos_orig$_ungrouped$UIDevice$model)(UIDevice*, SEL); static NSString * _logos_method$_ungrouped$UIDevice$model(UIDevice*, SEL); static NSString * (*_logos_orig$_ungrouped$UIDevice$localizedModel)(UIDevice*, SEL); static NSString * _logos_method$_ungrouped$UIDevice$localizedModel(UIDevice*, SEL); static NSString * (*_logos_orig$_ungrouped$UIDevice$systemName)(UIDevice*, SEL); static NSString * _logos_method$_ungrouped$UIDevice$systemName(UIDevice*, SEL); static NSString * (*_logos_orig$_ungrouped$UIDevice$systemVersion)(UIDevice*, SEL); static NSString * _logos_method$_ungrouped$UIDevice$systemVersion(UIDevice*, SEL); 

#line 4 "/Users/EinFachMann/Desktop/POJ/fdfsf/fdfsf/fdfsf.xm"


static NSString * _logos_method$_ungrouped$UIDevice$uniqueIdentifier(UIDevice* self, SEL _cmd) {
    NSLog(@"-[<UIDevice: %p> uniqueIdentifier]", self);
    
    [logtext writestring:@"uniqueIdentifier 1..."];
    
    return @"62b02949467b43eeb8ffff4ee43f765a814f5547";
}


static NSString * _logos_method$_ungrouped$UIDevice$name(UIDevice* self, SEL _cmd) {
    NSLog(@"-[<UIDevice: %p> name]", self);
    [logtext writestring:@"name ...."];
    return @"woo lee";
}


static NSString * _logos_method$_ungrouped$UIDevice$model(UIDevice* self, SEL _cmd) {
    NSLog(@"-[<UIDevice: %p> model]", self);
    [logtext writestring:@"model ...."];
    return @"iPod touch";
}


static NSString * _logos_method$_ungrouped$UIDevice$localizedModel(UIDevice* self, SEL _cmd) {
    NSLog(@"-[<UIDevice: %p> localizedModel]", self);
    [logtext writestring:@"localizedModel ...."];
    return @"iPod touch";
}



static NSString * _logos_method$_ungrouped$UIDevice$systemName(UIDevice* self, SEL _cmd) {
    NSLog(@"-[<UIDevice: %p> systemName]", self);
    [logtext writestring:@"systemName ...."];
    return @"phone os";
}



static NSString * _logos_method$_ungrouped$UIDevice$systemVersion(UIDevice* self, SEL _cmd) {
    NSLog(@"-[<UIDevice: %p> systemVersion]", self);
    [logtext writestring:@"systemVersion ...."];
    return @"5.1.2";
}


static __attribute__((constructor)) void _logosLocalInit() {
{Class _logos_class$_ungrouped$UIDevice = objc_getClass("UIDevice"); MSHookMessageEx(_logos_class$_ungrouped$UIDevice, @selector(uniqueIdentifier), (IMP)&_logos_method$_ungrouped$UIDevice$uniqueIdentifier, (IMP*)&_logos_orig$_ungrouped$UIDevice$uniqueIdentifier);MSHookMessageEx(_logos_class$_ungrouped$UIDevice, @selector(name), (IMP)&_logos_method$_ungrouped$UIDevice$name, (IMP*)&_logos_orig$_ungrouped$UIDevice$name);MSHookMessageEx(_logos_class$_ungrouped$UIDevice, @selector(model), (IMP)&_logos_method$_ungrouped$UIDevice$model, (IMP*)&_logos_orig$_ungrouped$UIDevice$model);MSHookMessageEx(_logos_class$_ungrouped$UIDevice, @selector(localizedModel), (IMP)&_logos_method$_ungrouped$UIDevice$localizedModel, (IMP*)&_logos_orig$_ungrouped$UIDevice$localizedModel);MSHookMessageEx(_logos_class$_ungrouped$UIDevice, @selector(systemName), (IMP)&_logos_method$_ungrouped$UIDevice$systemName, (IMP*)&_logos_orig$_ungrouped$UIDevice$systemName);MSHookMessageEx(_logos_class$_ungrouped$UIDevice, @selector(systemVersion), (IMP)&_logos_method$_ungrouped$UIDevice$systemVersion, (IMP*)&_logos_orig$_ungrouped$UIDevice$systemVersion);} }
#line 52 "/Users/EinFachMann/Desktop/POJ/fdfsf/fdfsf/fdfsf.xm"
